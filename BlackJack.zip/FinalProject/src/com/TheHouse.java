package com;

import java.util.ArrayList;
import java.util.Random;

import static java.util.Collections.reverse;
import static java.util.Collections.shuffle;

public class TheHouse {
    final String[] masterDeck = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
    ArrayList<Deck> deck = new ArrayList<>();
    ArrayList<Player> players = new ArrayList<>();
    int deckAmt = 1;

    public void intialize(int playerAmt, int compAmt) {
        int playerSize = playerAmt;
        boolean isValidDeckSize = false;
        boolean isHuman = false;

        for (int i = 0; i < playerSize; i++) {
            if (compAmt - 1 >= i) {
                isHuman = false;
            }
            else {
                isHuman = true;
            }
            players.add(new Player(playerSize - i - 1, isHuman));
        }

        reverse(players);

        do {
            if (playerAmt >= 13) {
                isValidDeckSize = false;
                playerAmt -= 13;
                deckAmt += 1;
            }
            else {
                isValidDeckSize = true;
            }
        } while (!isValidDeckSize);

        for(int d = 0; d < deckAmt;d++) {
            for (String b : masterDeck) {
                for (int i = 0; i < 4; i++) {
                    deck.add(new Deck(b));
                }
            }
        }

        shuffle(deck);
    }

    public int getValueDeck(String face, Player player) {
        int output = 0;

        if (face == "K" || face == "Q" || face == "J") {
            output = 10;
        }
        else if (face == "A") {
            if (player.getScore() > 11) {
                output = 11;
            }
            else {
                output = 1;
            }
        }
        else {
            output = Integer.parseInt(face);
        }
        return output;
    }

    public ArrayList<Deck> createCards() {
        ArrayList<Deck> newDeck = new ArrayList<>();
        for(int d = 0; d < deckAmt;d++) {
            for (String b : masterDeck) {
                for (int i = 0; i < 4; i++) {
                    newDeck.add(new Deck(b));
                }
            }
        }

        shuffle(newDeck);

        return newDeck;
    }

    public ArrayList<Deck> getDeck() {
        return deck;
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    boolean isValid (ArrayList <Player> players) {
        for (Player p : players) {
            if (p.hasBustOrPassed == false) {
                return false;
            }
        }
        return true;
    }
}
