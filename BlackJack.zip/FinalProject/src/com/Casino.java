package com;

import lib.ConsoleIO;

import java.util.*;

public class Casino {
    TheHouse theHouse = new TheHouse();
    int playerAmt;
    int compAmt;

    public void playBlackJack() {
        playerAmt = ConsoleIO.inputFromUserInt("How many players do you want? Please enter a number between 1 and 28: ", 1, 28);
        compAmt = ConsoleIO.inputFromUserInt("How many players are going to be cpu players? Please enter a numbetween 0 and " + playerAmt + ": ", 0, playerAmt);
        theHouse.intialize(playerAmt, compAmt);
        playerAction();
    }

    public void playerAction () {
        ArrayList<Deck> deck = theHouse.getDeck();
        ArrayList<Player> players = theHouse.getPlayers();
        Player theHousePlayer = new Player(players.size(), false);
        ArrayList<Player> winners = new ArrayList<>();

        boolean continuePlaying = false;
        do {
            boolean hasEveryoneFoldedOrBust = false;
            do {
                for (int i = 0; i < players.size(); i++) {
                    if (players.get(i).isHuman) {
                        if (players.get(i).getScore() > 21) {
                            System.out.println("Player " + (i + 1) + ". You have overdraft.");
                            players.get(i).setHasBustOrPassed(true);
                        }
                        else {
                            System.out.println("Player " + (i + 1) + ". Your current score is: " + players.get(i).score);
                            String[] options = {"Draw", "Fold"};
                            int ouput = ConsoleIO.promptForMenuSelection(options, false);

                            String dealt = "";

                            if (ouput == 1) {

                                if(deck.size()>0) {
                                    dealt = deck.get(0).getFace();
                                    deck.remove(0);
                                }

                                players.get(i).addScore(theHouse.getValueDeck(dealt ,players.get(i)));
                                System.out.println("You drew a " + dealt + ". Your current score is: " + players.get(i).score);
                            }
                            else {
                                players.get(i).setHasBustOrPassed(true);
                            }
                        }
                    }
                    else {
                        if (players.get(i).getScore() > 21) {
                            Random rngDepartment = new Random();
                            int randInt = rngDepartment.nextInt(5);

                            String dealt = "";

                            if (randInt != 4) {
                                if(deck.size()>0) {
                                    dealt = deck.get(0).getFace();
                                    deck.remove(0);
                                }

                                players.get(i).addScore(theHouse.getValueDeck(dealt ,players.get(i)));
                            }
                            else {
                                players.get(i).setHasBustOrPassed(true);
                            }
                        }
                        else {
                            players.get(i).setHasBustOrPassed(true);
                        }
                    }
                }

                if (theHousePlayer.score < 17) {
                    String dealt = "";

                    if(deck.size()>0) {
                        dealt = deck.get(0).getFace();
                        deck.remove(0);
                    }

                    theHousePlayer.addScore(theHouse.getValueDeck(dealt, theHousePlayer));
                }

                hasEveryoneFoldedOrBust = theHouse.isValid(players);

            } while (!hasEveryoneFoldedOrBust);

            winners.clear();
            winners = players;
            for (int i = 0; i < winners.size(); i++) {
                if (winners.get(i).score > 21) {
                    winners.remove(i);
                }
            }

            Collections.sort(winners);

            //Has everyone bust
            if (winners.isEmpty()) {
                System.out.println("Everyone busted.\nThe house has one this round.");
            }
            //Has only the house bust
            else  if (!(winners.isEmpty()) && theHousePlayer.score > 21) {
                System.out.println("The House: Busted");
                System.out.println("Player " + (winners.get(0).playerId + 1) + " has won this round.");
            }
            //Has the best of the people vs the house
            //The house won the comparison
            else if ((winners.get(0).score > theHousePlayer.score) && theHousePlayer.score <= 21) {
                System.out.println("The House: " + theHousePlayer.score);
                System.out.println("Player " + (winners.get(0).playerId + 1) + " has won this round. Score: " + winners.get(0).playerId);
            }
            //The player won the comparison
            else if ((winners.get(0).score < theHousePlayer.score) && theHousePlayer.score <= 21) {
                System.out.println("The House: " + theHousePlayer.score);
                System.out.println("The house won this round.");
            }

            continuePlaying = ConsoleIO.promptForBoolean("\nDo you want to continue playing? (Yes/No): ", "Yes", "No");
            if (continuePlaying) {
                deck.clear();
                for (int i = 0; i < players.size(); i++) {
                    players.get(i).setScore(0);
                }
                theHousePlayer.setScore(0);

                deck = theHouse.createCards();
            }
        } while (continuePlaying);
    }
}
