package com;

import lib.ConsoleIO;

import java.util.*;

public class Casino {
    TheHouse theHouse = new TheHouse();
    int playerAmt;
    int compAmt;

    public void playBlackJack() {
        playerAmt = ConsoleIO.inputFromUserInt("How many players do you want? Please enter a number between 1 and 28: ", 1, 28);
        compAmt = ConsoleIO.inputFromUserInt("How many players are going to be cpu players? Please enter a numbetween 0 and " + playerAmt + ": ", 0, playerAmt);
        theHouse.intialize(playerAmt, compAmt);
        playerAction();
    }

    public void playerAction () {
        ArrayList<Deck> deck = theHouse.getDeck();
        ArrayList<Player> players = theHouse.getPlayers();
        Player theHousePlayer = new Player(players.size(), false);

        boolean continuePlaying = false;
        do {
            boolean hasEveryoneFoldedOrBust = false;
            do {
                for (int i = 0; i < players.size(); i++) {
                    if (players.get(i).isHuman) {
                        if (players.get(i).getScore() > 21) {
                            System.out.println("Player " + (i + 1) + ". You have overdraft.");
                            players.get(i).setHasBustOrPassed(true);
                        }
                        else {
                            System.out.println("Player " + (i + 1) + ". Your current score is: " + players.get(i).score);
                            String[] options = {"Draw", "Fold"};
                            int ouput = ConsoleIO.promptForMenuSelection(options, false);

                            String dealt = "";

                            if (ouput == 1) {

                                if(deck.size()>0) {
                                    dealt = deck.get(0).getFace();
                                    deck.remove(0);
                                }

                                players.get(i).addScore(theHouse.getValueDeck(dealt ,i));
                                System.out.println("You drew a " + dealt + ". Your current score is: " + players.get(i).score);
                            }
                            else {
                                players.get(i).setHasBustOrPassed(true);
                            }
                        }
                    }
                    else {
                        if (players.get(i).getScore() != 22 && players.get(i).getScore() < 21) {
                            Random rngDepartment = new Random();
                            int randInt = rngDepartment.nextInt(1);
                            boolean willDraw = (randInt == 1);

                            String dealt = "";

                            if (willDraw) {
                                if(deck.size()>0) {
                                    dealt = deck.get(0).getFace();
                                    deck.remove(0);
                                }

                                players.get(i).addScore(theHouse.getValueDeck(dealt ,i));
                            }
                            else {
                                System.out.println("The computer skipped.");
                                players.get(i).setHasBustOrPassed(true);
                            }
                        }
                    }
                }

                if (theHousePlayer.score < 21) {
                    String dealt = "";

                    if(deck.size()>0) {
                        dealt = deck.get(0).getFace();
                        deck.remove(0);
                    }

                    theHousePlayer.addScore(theHouse.getValueDeck(dealt, theHousePlayer.playerId));
                    System.out.println(theHousePlayer.score);
                }

                for (int i = 0; i < players.size(); i++){
                    for (int j = 0; j < players.size(); j++) {
                        if((players.get(i).hasBustOrPassed) && (players.get(j).hasBustOrPassed)) {
                            hasEveryoneFoldedOrBust = true;
                        }
                        else {
                            hasEveryoneFoldedOrBust = false;
                        }
                    }

                }

            } while (!hasEveryoneFoldedOrBust);

            ArrayList<Player> winners = players;
            for (int i = 0; i < winners.size(); i++) {
                if (winners.get(i).score > 21) {
                    winners.remove(i);
                }
            }

            Collections.sort(winners);

            if (winners.isEmpty()) {
                System.out.println("The house has one this round.");
            }
            else if ((winners.get(0).score > theHousePlayer.score) && theHousePlayer.score < 22) {
                System.out.println("The house: " + theHousePlayer.score);
                System.out.println("Player " + (winners.get(0).playerId + 1) + " has won this round.");
            }
            else {
                System.out.println("The house has one this round.");
            }

            continuePlaying = ConsoleIO.promptForBoolean("Do you want to continue playing? (Yes/No): ", "Yes", "No");
            if (continuePlaying) {
                deck.clear();
                for (int i = 0; i < players.size(); i++) {
                    players.get(i).setScore(0);
                }
                theHousePlayer.setScore(0);

                deck = theHouse.createCards();
            }
        } while (continuePlaying);
    }
}
