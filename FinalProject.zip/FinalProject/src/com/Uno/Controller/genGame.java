package com.Uno.Controller;

import com.Uno.Model.Unocard;
import com.Uno.Viewer.View;

import java.util.ArrayList;

public class genGame {
    private static ArrayList<Unocard> playerdeck = new ArrayList<>();
    private static ArrayList<Unocard> playerdeck2 = new ArrayList<>();
    private static ArrayList<Unocard> compdeck = new ArrayList<>();
    private static ArrayList<Unocard> compdeck2 = new ArrayList<>();
    private static int win;
    private static Unocard topCard;
    private static int choiceIndex;
    private static String currentColor;
    private static boolean keepLooping = true;
    private static int result;
    private static int chosenColor;
    private static boolean playersTurn = true;
    private static String player1;
    private static String player2;
    private static String CPU1;
    private static String CPU2;

    public static void PVC() {
        String prompt1 = "Enter Player's Name: ";
        String prompt2 = "Enter CPU's Name: ";
        player1 = View.promptForString(prompt1,false);
        CPU1 = View.promptForString(prompt2,false);
        while (keepLooping) {
            setup(playerdeck, compdeck);
            for (playersTurn = true; win == 0; playersTurn ^= true) {
                choiceIndex = 0;
                View.outputToConsole("\nThe top card is: " + topCard.getFace());
                if (playersTurn) {
                    playerTurn(compdeck, playerdeck,player1);

                } else {
                    cpuTurn(playerdeck, compdeck, CPU1);

                    determinesWinner(playerdeck, compdeck);
                }
            }
            showWinner(player1,CPU1);
            break;
        }
    }
    public static void PVP(){
        String prompt1 = "Enter Player 1's Name: ";
        String prompt2 = "Enter Player 2's Name: ";
        player1 = View.promptForString(prompt1,false);
        player2 = View.promptForString(prompt2,false);
        while(keepLooping){
            setup(playerdeck,playerdeck2);
            for (playersTurn = true; win == 0; playersTurn ^= true) {
                choiceIndex = 0;
                View.outputToConsole("\nTop card is " + topCard.getFace());
                if(playersTurn) {
                    playerTurn(playerdeck2,playerdeck, player1);
                }
                else {
                  playerTurn(playerdeck,playerdeck2,player2);
                determinesWinner(playerdeck,playerdeck2);
                }
            }
            showWinner("PLayer1","PLayer2");
            break;
        }
    }
    public static void CVC(){
        String prompt1 = "Enter CPU 1's Name: ";
        String prompt2 = "Enter CPU 2's Name: ";
        CPU1 = View.promptForString(prompt1,false);
        CPU2 = View.promptForString(prompt2,false);
        while(keepLooping){
            setup(compdeck,compdeck2);
            for (playersTurn = true; win == 0; playersTurn ^= true) {
                choiceIndex = 0;
                View.outputToConsole("\nTop card is " + topCard.getFace());
                if(playersTurn) {
                    cpuTurn(compdeck2,compdeck,CPU1);
                }
                else {
                    cpuTurn(compdeck,compdeck2,CPU2);

                    determinesWinner(compdeck,compdeck2);
                }
            }
           showWinner(CPU1,CPU2);
            break;
        }
    }

    private static void setup(ArrayList p1, ArrayList p2){
        p1.clear();
        p2.clear();
        win = 0;
        topCard = new Unocard();
        currentColor = topCard.color;
        if(topCard.value == 13 || topCard.value == 14){
            topCard = new Unocard();
            View.outputToConsole("\nHello!! Welcome to Uno!!");
            createDecks(p1,p2);
        }
        else {
            View.outputToConsole("\nHello!! Welcome to Uno!!");
            createDecks(p1,p2);
        }
    }
    public static void createDecks(ArrayList p1, ArrayList p2){
        draw(7, p1);
        View.outputToConsole("first deck set");
        draw(7, p2);
        View.outputToConsole("second deck set");

    }


    public static void draw(int cards, ArrayList<Unocard> deck)
    {
        for (int i = 0; i < cards; i++)
            deck.add(new Unocard() );

    }
    private static void printPlayerDeck(ArrayList<Unocard> deck){
        for (int i = 0; i < deck.size(); i++)
        {
            View.outputToConsole((i + 1) + ") " +
                    (deck.get(i) ).getFace() + "\n");
        }
        View.outputToConsole((deck.size() + 1 ) + ") " + "Draw card" + "\n" +
                (deck.size() + 2) + ") " + "Quit");
    }

    private static void playerTurn(ArrayList otherPlayer, ArrayList<Unocard> deck, String name){
            View.outputToConsole(name + "'s turn");
            printPlayerDeck(deck);
            do {
                String prompt = "Please enter your choice: ";
                result = View.promptForInt(prompt,1,deck.size()+2);
            } while (!keepLooping);
            choiceIndex = result - 1;
            if(result == deck.size()+2){
                View.outputToConsole("Have a nice day");
                keepLooping = false;

            }
            if (choiceIndex == deck.size())
                draw(1, deck);
            else if (choiceIndex == deck.size() + 1)
                keepLooping = false;
            else if ((deck.get(choiceIndex)).canPlace(topCard, currentColor)) {
                topCard = deck.get(choiceIndex);
                deck.remove(choiceIndex);
                currentColor = topCard.color;
                if (topCard.value >= 10) {
                    playersTurn = false;

                    switch (topCard.value) {
                        case 12: // Draw 2
                            View.outputToConsole("Drawing 2 cards...");
                            draw(2, otherPlayer);
                            break;

                        case 13:
                        case 14:
                            do
                            {
                                StringBuilder br = new StringBuilder("please enter a number ot choose the color");
                                br.append("\n1) Red").append("\n2) Green").append("\n3) Blue").append("\n4) Yellow");
                                br.append("\nEnter your number here: ");
                                String colorPrompt = br.toString();
                                chosenColor = View.promptForInt(colorPrompt,1,4);
                            } while (!keepLooping);
                            if (chosenColor == 1) {
                                currentColor = "Red";
                                View.outputWildColor('R', "The Wild Card is set to Red");
                            }
                            else if (chosenColor == 2) {
                                currentColor = "Green";
                                View.outputWildColor('G',"The Wild Card is set to Green");
                            }
                            else if (chosenColor == 3) {
                                currentColor = "Blue";
                                View.outputWildColor('B',"The Wild Card is set to Blue");
                            }
                            else if (chosenColor == 4) {
                                currentColor = "Yellow";

                                View.outputWildColor('Y', "The Wild Card is set to Yellow");
                            }
                            if (topCard.value == 14) // Wild draw 4
                            {
                                View.outputToConsole("Drawing 4 cards...");
                                draw(4, otherPlayer);
                            }
                            break;
                    }
                }
            } else
                View.outputErrorToConsole("Invalid choice. Turned Skipped");
            keepLooping = true;
        }

    private static void determinesWinner(ArrayList p1, ArrayList p2){
        if (p1.size() == 0)
            win = 1;
        else if (p2.size() == 0)
            win = -1;
    }
    public static void showWinner(String p1, String p2){
        if (win == 1)
            View.outputToConsole( p1 + " Wins!!");
        else
            View.outputToConsole( p2 + " Wins!!");
    }


    private static void cpuTurn(ArrayList otherPlayer, ArrayList<Unocard>deck, String Name){
        View.outputToConsole( Name + "'s Turn, current deck size" + (deck.size())
                + " cards left!" + ((deck.size() == 1) ? "...Uno!":"") );
        for (choiceIndex = 0; choiceIndex < deck.size(); choiceIndex++)
        {
           if ( (deck.get(choiceIndex)).canPlace(topCard, currentColor) )
                break;
        }

        if (choiceIndex == deck.size() )
        {
            View.outputToConsole("I've got nothing! Drawing a card...");
            draw(1,deck);
        } else
        {
            topCard = deck.get(choiceIndex);
            deck.remove(choiceIndex);
            currentColor = topCard.color;
            View.outputToConsole("I choose " + topCard.getFace() + " !");


            if (topCard.value >= 10)
            {
                playersTurn = true;

                switch (topCard.value)
                {
                    case 12:
                        View.outputToConsole("Drawing 2 cards for you...");
                        draw(2,otherPlayer);
                        break;

                    case 13: case 14:
                    do
                    {
                        currentColor = new Unocard().color;
                    } while (currentColor == "none");

                    View.outputToConsole("New color is " + currentColor);
                    if (topCard.value == 14) // Wild draw 4
                    {
                        View.outputToConsole("Drawing 4 cards for you...");
                        draw(4,otherPlayer);
                    }
                    break;
                }
            }
        }
    }

}
