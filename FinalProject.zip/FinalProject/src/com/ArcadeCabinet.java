package com;

import com.BlackJack.Casino;
import lib.ConsoleIO;
import Sweeper.Minesweeper;

public class ArcadeCabinet {
    public void startUP() {
        boolean isValid = true;
        do {
            ConsoleIO.soutMethod("\nWelcome to DevCat Console Cabinet!!!");
            String[] optionsGame = {"Black Jack", "UNO - (Out of Order)", "Minesweeper"};
            int input = ConsoleIO.promptForMenuSelection(optionsGame, true);

            switch (input) {
                case 1:
                    isValid = true;
                    new Casino().playBlackJack();
                    break;
                case 2:
                    isValid = true;
                    break;
                case 3:
                    isValid = true;
                    new Minesweeper().runMinesweeper();
                    break;
                case 0:
                    isValid = false;
                    break;
            }
        } while (isValid);
    }
}
