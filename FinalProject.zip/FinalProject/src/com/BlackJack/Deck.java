package com.BlackJack;

public class Deck {
    private String face = "X";

    public Deck(String face) {
        setFace(face);
    }

    public void setFace(String face) {
        this.face = face;
    }

    public String getFace() {
        return face;
    }
}
