package com.BlackJack;

public class Player implements Comparable<Player>{
    int score = 0;
    int playerId = 0;
    boolean isHuman = true;
    boolean hasBustOrPassed = false;

    public Player (int playerId, boolean isHuman) {
        setPlayerId(playerId);
        this.isHuman = isHuman;
    }

    public void setHasBustOrPassed(boolean hasBustOrPassed) {
        this.hasBustOrPassed = hasBustOrPassed;
    }

    public void setPlayerId(int playerId) {
        this.playerId = playerId;
    }

    public void setScore(int score) {
        this.score = score;
    }

    @Override
    public int compareTo(Player obj) {
        return obj.score-this.score;
    }


    public void addScore(int amtAdded) {
        this.score += amtAdded;
    }

    public int getScore() {
        return score;
    }


}
