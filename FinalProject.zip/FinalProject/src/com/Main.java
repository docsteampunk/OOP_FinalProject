package com;

import com.BlackJack.Casino;

public class Main {

    public static void main(String[] args) {
        new ArcadeCabinet().startUP();
    }
}