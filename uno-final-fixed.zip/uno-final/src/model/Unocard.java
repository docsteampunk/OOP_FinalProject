package model;

import java.util.Random;

public class Unocard {
    public String color;
    public int value;
    private Random rand;
    private String face;
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";

    // Creates a random card
    public Unocard()
    {
        //This one gens the number
        rand = new Random();
        value = rand.nextInt(15);
        // This one assigns the color
        rand = new Random();
        switch(rand.nextInt(4) )
        {
            case 0: color = "Red";
                break;
            case 1: color = "Green";
                break;
            case 2: color = "Blue";
                break;
            case 3: color = "Yellow";
                break;
        }
        // this makes it a wild card
        if (value >= 13)
            color = "none";
    }

    public String getFace()
    {
       //this is what the player or user will see :)
        face = "[";
        if (color != "none")
        {
            face += this.color + " ";
        }

        switch(this.value)
        {
            default: face += String.valueOf(this.value);
                break;
            case 10: face += "Skip";
                break;
            case 11: face += "Reverse";
                break;
            case 12: face += "Draw 2";
                break;
            case 13: face += ANSI_RED + "W" + ANSI_RESET + ANSI_BLUE + "i" + ANSI_RESET + ANSI_YELLOW + "l" + ANSI_RESET + ANSI_GREEN + "d" + ANSI_RESET;
                break;
            case 14: face += "Wild Draw 4";
                break;
        }
        if(value == 13) {
            face += ANSI_PURPLE + "]" + ANSI_RESET;
        }
        else{
            face += "]";
        }
        if(color == "Red") {
            return ANSI_RED + face + ANSI_RESET;
        }
        else if(color == "Blue"){
            return ANSI_BLUE + face + ANSI_RESET;
        }
        else if(color == "Green"){
            return ANSI_GREEN + face + ANSI_RESET;
        }
        else if(color == "Yellow"){
            return ANSI_YELLOW + face + ANSI_RESET;
        }
        else{
            return face;
        }
    }

    // this determines if you can place this card on top of a given card
    public boolean canPlace(Unocard o, String c)
    {
        if (this.color == c)
            return true;
        else if (this.value == o.value)
            return true;
        else if (this.color == "none")
            return true;
        return false;
    }
}
