package viewer;

import controller.genGame;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class View {
    /**  These are used to show errors **/
    public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
    public static final String ANSI_BLACK = "\u001B[30m";
    /** These are used to just the color of the text**/
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";

    public static int menuPrompt(){
        StringBuilder sb = new StringBuilder("\nUNO\n").append("Please, choose one of the following:\n\n");
        sb.append("1) Player VS Player\n").append("2) Player VS CPU\n").append("3) CPU VS CPU\n").append("\n0) Exit\n");
        sb.append("\nEnter the number for selection: ");

        String startMenu = ANSI_PURPLE + sb.toString() + ANSI_RESET;
        int result = promptForInt(startMenu,0,3);
        return result;
    }
    public static void reactToResult(int result) {

        switch (result) {
            case 0:
                outputToConsole("You chose to exit have a great day :)");
                break;
            case 1:
                genGame.PVP();
                homeRun();
                break;
            case 2:
                genGame.PVC();
                homeRun();
                break;
            case 3:
                genGame.CVC();
                homeRun();
                break;
            default:
                outputToConsole("This was not supposed to happened");
        }
    }
    public static void homeRun() {
        int userSelection = menuPrompt();
        reactToResult(userSelection);
    }








    public static void outputWildColor(char color, String output){
        if(color == 'R'){
            System.out.println(ANSI_RED + output + ANSI_RESET);
        }
        else if(color == 'B'){
            System.out.println(ANSI_BLUE + output + ANSI_RESET);
        }
        else if(color == 'G'){
            System.out.println(ANSI_GREEN + output + ANSI_RESET);
        }
        else{
            System.out.println(ANSI_YELLOW + output + ANSI_RESET);
        }
    }


    public static void outputErrorToConsole(String output){
        System.out.println(ANSI_RED_BACKGROUND + ANSI_BLACK + output + ANSI_RESET);
    }
    public static void outputToConsole(String output){
        System.out.println(ANSI_PURPLE + output + ANSI_RESET);
    }
    public static String promptForString(String prompt, boolean allowBlank){
        if(prompt == null || prompt.isBlank()){
            throw new IllegalArgumentException(ANSI_RED_BACKGROUND + ANSI_BLACK + "The prompt cannot be null, empty, or just white space. Prompt: " + prompt + ANSI_RESET);
        }

        String input = null;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        boolean isNoBueno = true;

        do{
            System.out.print(ANSI_PURPLE + prompt + ANSI_RESET);
            try{
                input = br.readLine();
                isNoBueno = input == null || (!allowBlank && input.isBlank());
                if(isNoBueno){
                    System.out.println(ANSI_RED_BACKGROUND + ANSI_BLACK + "Invalid input, please try again" + ANSI_RESET);
                }

            }catch (IOException ioe){
                System.out.println(ANSI_RED_BACKGROUND + ANSI_BLACK + "There was no input received, please try again" + ANSI_RESET);
            }
        }while(isNoBueno);

        return input;
    }
    public static int promptForInt(String prompt, int min, int max){
        if(min > max){
            throw new IllegalArgumentException(ANSI_RED_BACKGROUND + ANSI_BLACK + "Min cannot exceed max, min= " + min + "; max= " + max + ANSI_RESET);
        }
        int userNumber = -1;
        boolean isNoBueno = true;

        do {
            String input = promptForString(prompt, false);
            try {
                userNumber = Integer.parseInt(input);
                isNoBueno = userNumber < min || userNumber > max;
            }catch(NumberFormatException nfe){
                //No need to do anything here
            }
            if(isNoBueno){
                System.out.println(ANSI_RED_BACKGROUND + ANSI_BLACK + "You must enter a whole number between " + min + " and " + max + ", please try again" + ANSI_RESET);
            }
        }while (isNoBueno);

        return userNumber;
    }
}
