package retro;

import lib.ConsoleIO;

import java.util.Random;

public class minesweeper {
    static Random rng = new Random();




    

    //All other variables used
    public static String playerName = "";
    public static int playerChosenRow = 0;
    public static int playerChosenColumn = 0;
    public static boolean keepGameGoing = true;
    public static String playerContinues = "";
    public static int difficulty = 0;

    public static int flagWinCon = 0;

    public static int row = 0;
    public static int column = 0;


    public static int bomb1Row = -10;
    public static int bomb1Column = -10;

    public static int bomb2Row = -10;
    public static int bomb2Column = -10;

    public static int bomb3Row = -10;
    public static int bomb3Column = -10;

    public static int bomb4Row = -10;
    public static int bomb4Column = -10;

    public static int bomb5Row = -10;
    public static int bomb5Column = -10;

    public static int bomb6Row = -10;
    public static int bomb6Column = -10;

    public static int bomb7Row = -10;
    public static int bomb7Column = -10;

    public static int bomb8Row = -10;
    public static int bomb8Column = -10;

    public static int bomb9Row = -10;
    public static int bomb9Column = -10;

    public static int bomb10Row = -10;
    public static int bomb10Column = -10;


    public static int magnusOfDifficulty = 0;
    public static int maxPieceCount = 0;



    public static void runMinesweeper(){



        playerName = ConsoleIO.inputFromUserString("Please enter your name: ", false);
        playerContinues = ConsoleIO.inputFromUserString("Hello, " + playerName + ". Would you like to play a game of Minesweeper?(y/n): ", false);
        if(playerContinues.equals("y") || playerContinues.equals("Y") || playerContinues.equals("Yes") || playerContinues.equals("yes")) {
            ConsoleIO.soutMethod("Please select a difficulty(The amount of mines present)");
            String[] difficultyMenu = {
                    "Easy",
                    "Medium",
                    "Hard"
            };
            difficulty = ConsoleIO.promptForMenuSelection(difficultyMenu, false);
            maxPieceCount = 0;
            keepGameGoing = true;
        }else{
            keepGameGoing = false;
            ConsoleIO.soutMethod("Why choose Minesweeper if you didn't want to play it?");
        }






        if (keepGameGoing == true) {



            do {
                //Different difficulty settings
                switch (difficulty) {
                    case 1:
                        bomb1Column = rng.nextInt(10);
                        bomb1Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 1 is: " + bomb1Column + ":Column " + bomb1Row + ":Row");

                        bomb2Column = rng.nextInt(10);
                        bomb2Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 2 is: " + bomb2Column + ":Column " + bomb2Row + ":Row");

                        bomb3Column = rng.nextInt(10);
                        bomb3Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 3 is: " + bomb3Column + ":Column " + bomb3Row + ":Row");

                        magnusOfDifficulty = 1;
                        ConsoleIO.soutMethod("Difficulty is easy");
                        maxPieceCount = 97;
                        break;
                    case 2:
                        bomb1Column = rng.nextInt(10);
                        bomb1Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 1 is: " + bomb1Column + ":Column " + bomb1Row + ":Row");

                        bomb2Column = rng.nextInt(10);
                        bomb2Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 2 is: " + bomb2Column + ":Column " + bomb2Row + ":Row");

                        bomb3Column = rng.nextInt(10);
                        bomb3Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 3 is: " + bomb3Column + ":Column " + bomb3Row + ":Row");

                        bomb4Column = rng.nextInt(10);
                        bomb4Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 4 is: " + bomb4Column + ":Column " + bomb4Row + ":Row");

                        bomb5Column = rng.nextInt(10);
                        bomb5Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 5 is: " + bomb5Column + ":Column " + bomb5Row + ":Row");

                        magnusOfDifficulty = 2;
                        ConsoleIO.soutMethod("Difficulty is normal");
                        maxPieceCount = 95;
                        break;
                    case 3:
                        bomb1Column = rng.nextInt(10);
                        bomb1Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 1 is: " + bomb1Column + ":Column " + bomb1Row + ":Row");

                        bomb2Column = rng.nextInt(10);
                        bomb2Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 2 is: " + bomb2Column + ":Column " + bomb2Row + ":Row");

                        bomb3Column = rng.nextInt(10);
                        bomb3Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 3 is: " + bomb3Column + ":Column " + bomb3Row + ":Row");

                        bomb4Column = rng.nextInt(10);
                        bomb4Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 4 is: " + bomb4Column + ":Column " + bomb4Row + ":Row");

                        bomb5Column = rng.nextInt(10);
                        bomb5Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 5 is: " + bomb5Column + ":Column " + bomb5Row + ":Row");

                        bomb6Column = rng.nextInt(10);
                        bomb6Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 6 is: " + bomb6Column + ":Column " + bomb6Row + ":Row");

                        bomb7Column = rng.nextInt(10);
                        bomb7Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 7 is: " + bomb7Column + ":Column " + bomb7Row + ":Row");

                        bomb8Column = rng.nextInt(10);
                        bomb8Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 8 is: " + bomb8Column + ":Column " + bomb8Row + ":Row");

                        bomb9Column = rng.nextInt(10);
                        bomb9Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 9 is: " + bomb9Column + ":Column " + bomb9Row + ":Row");

                        bomb10Column = rng.nextInt(10);
                        bomb10Row = rng.nextInt(10);
                        ConsoleIO.soutMethod("The value of bomb 10 is: " + bomb10Column + ":Column " + bomb10Row + ":Row");

                        magnusOfDifficulty = 3;
                        ConsoleIO.soutMethod("Difficulty is hard");
                        maxPieceCount = 90;
                        break;
                }

                String[][] mineField = {
                        {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
                        {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
                        {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
                        {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
                        {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
                        {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
                        {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
                        {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
                        {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
                        {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-"}
                };


                int pieceCount = 0;
                boolean bombExploded = false;


                //The entire game method
                do {
                    for (String[] strings : mineField) {
                        for (String m : strings) {
                            System.out.print(m + "\t");
                        }
                        System.out.println();
                    }

                    int userColumn = 0;
                    int userRow = 0;


                    //Flags a tile for "mine possibility"
                    String userFlagOrPlace = ConsoleIO.inputFromUserString(playerName + ", do you wish to flag a block?(Y/N). If no is chosen, you will reveal a block instead: ", false);

                    if (userFlagOrPlace.equals("y") || userFlagOrPlace.equals("Y") || userFlagOrPlace.equals("Yes") || userFlagOrPlace.equals("yes")) {
                        userColumn = ConsoleIO.inputFromUserInt(playerName + ", please enter the number of the column you wish to flag: ", 1, 10) - 1;
                        userRow = ConsoleIO.inputFromUserInt(playerName + ", please enter the number of the row you wish to flag: ", 1, 10) - 1;
                        if (mineField[userRow][userColumn] == "-") {
                            mineField[userRow][userColumn] = "F";

                            if((userRow == bomb1Row && userColumn == bomb1Column) || (userRow == bomb2Row && userColumn == bomb2Column) || (userRow == bomb3Row && userColumn == bomb3Column) || (userRow == bomb4Row && userColumn == bomb4Column) || (userRow == bomb5Row && userColumn == bomb5Column) || (userRow == bomb6Row && userColumn == bomb6Column) || (userRow == bomb7Row && userColumn == bomb7Column) || (userRow == bomb8Row && userColumn == bomb8Column) || (userRow == bomb9Row && userColumn == bomb9Column) || (userRow == bomb10Row && userColumn == bomb10Column)){
                                flagWinCon += 1;
                                if (difficulty == 1 && flagWinCon == 3){
                                    bombExploded = true;
                                    flagWinCon = 0;
                                    ConsoleIO.soutMethod("You WIN! You flagged all the bombs");
                                }else if (difficulty == 2 && flagWinCon ==5){
                                    bombExploded = true;
                                    flagWinCon = 0;
                                    ConsoleIO.soutMethod("You WIN! You flagged all the bombs");
                                }else if (difficulty == 3 && flagWinCon == 10){
                                    bombExploded = true;
                                    flagWinCon = 0;
                                    ConsoleIO.soutMethod("You WIN! You flagged all the bombs");
                                }
                            }

                        } else if (mineField[userRow][userColumn] == "F") {
                            ConsoleIO.soutMethod("This tile has already been flagged");
                        }




                    } else {
                        userColumn = ConsoleIO.inputFromUserInt(playerName + ", please enter the column of the block you wish to reveal: ", 1, 10) - 1;
                        userRow = ConsoleIO.inputFromUserInt(playerName + ", please enter the row of the block you wish to reveal: ", 1, 10) - 1;


                        //Mine Checker
                        switch (magnusOfDifficulty) {
                            case 1:
                                if ((userRow == bomb1Row && userColumn == bomb1Column) || (userRow == bomb2Row && userColumn == bomb2Column) || (userRow == bomb3Row && userColumn == bomb3Column)) {
                                    bombExploded = true;
                                    mineField[bomb1Row][bomb1Column] = "*";
                                    mineField[bomb2Row][bomb2Column] = "*";
                                    mineField[bomb3Row][bomb3Column] = "*";

                                    for (String[] strings : mineField) {
                                        for (String m : strings) {
                                            System.out.print(m + "\t");
                                        }
                                        System.out.println();
                                    }

                                    ConsoleIO.soutMethod("Sorry, but a mine has exploded");
                                }
                                break;
                            case 2:
                                if ((userRow == bomb1Row && userColumn == bomb1Column) || (userRow == bomb2Row && userColumn == bomb2Column) || (userRow == bomb3Row && userColumn == bomb3Column) || (userRow == bomb4Row && userColumn == bomb4Column) || (userRow == bomb5Row && userColumn == bomb5Column)) {
                                    bombExploded = true;
                                    mineField[bomb1Row][bomb1Column] = "*";
                                    mineField[bomb2Row][bomb2Column] = "*";
                                    mineField[bomb3Row][bomb3Column] = "*";
                                    mineField[bomb4Row][bomb4Column] = "*";
                                    mineField[bomb5Row][bomb5Column] = "*";

                                    for (String[] strings : mineField) {
                                        for (String m : strings) {
                                            System.out.print(m + "\t");
                                        }
                                        System.out.println();
                                    }
                                    ConsoleIO.soutMethod("Sorry, but a mine has exploded");
                                }
                                break;
                            case 3:
                                if ((userRow == bomb1Row && userColumn == bomb1Column) || (userRow == bomb2Row && userColumn == bomb2Column) || (userRow == bomb3Row && userColumn == bomb3Column) || (userRow == bomb4Row && userColumn == bomb4Column) || (userRow == bomb5Row && userColumn == bomb5Column) || (userRow == bomb6Row && userColumn == bomb6Column) || (userRow == bomb7Row && userColumn == bomb7Column) || (userRow == bomb8Row && userColumn == bomb8Column) || (userRow == bomb9Row && userColumn == bomb9Column) || (userRow == bomb10Row && userColumn == bomb10Column)){
                                    bombExploded = true;
                                    mineField[bomb1Row][bomb1Column] = "*";
                                    mineField[bomb2Row][bomb2Column] = "*";
                                    mineField[bomb3Row][bomb3Column] = "*";
                                    mineField[bomb4Row][bomb4Column] = "*";
                                    mineField[bomb5Row][bomb5Column] = "*";
                                    mineField[bomb6Row][bomb6Column] = "*";
                                    mineField[bomb7Row][bomb7Column] = "*";
                                    mineField[bomb8Row][bomb8Column] = "*";
                                    mineField[bomb9Row][bomb9Column] = "*";
                                    mineField[bomb10Row][bomb10Column] = "*";

                                    for (String[] strings : mineField) {
                                        for (String m : strings) {
                                            System.out.print(m + "\t");
                                        }
                                        System.out.println();
                                    }

                                    ConsoleIO.soutMethod("Sorry, but a mine has exploded");
                                }
                                break;
                        }


                        if ((userRow == bomb1Row && userColumn == bomb1Column + 1) || (userRow == bomb1Row && userColumn == bomb1Column -1) ||(userRow == bomb1Row + 1 && userColumn == bomb1Column) || (userRow == bomb1Row - 1 && userColumn == bomb1Column)) {
                            mineField[userRow][userColumn] = "1";
                            pieceCount += 1;
                        }else {
                            mineField[userRow][userColumn] = "0";
                            pieceCount += 1;
                        }




                        if(pieceCount == maxPieceCount){
                            bombExploded = true;
                            ConsoleIO.soutMethod("You have chosen every tile that isn't a bomb. You win!!! \n");
                        }

                    }
                } while (bombExploded == false);

                playerContinues = ConsoleIO.inputFromUserString("Would you like to try again?(y/n): ", false);
                if(playerContinues.equals("y") || playerContinues.equals("Y") || playerContinues.equals("Yes") || playerContinues.equals("yes")){
                    keepGameGoing = true;
                }else{
                    keepGameGoing = false;
                }


            } while (keepGameGoing);
        }

    }


}
