package retro;

import lib.ConsoleIO;

public class Main {

    public static void main(String[] args) {
	    gameSelection();
    }

    public static void gameSelection(){
        int gameChosen = 1;
        String [] gameMenu = {
            "BlackJack",
            "Uno",
            "Minesweeper"
        };
        do {
            gameChosen = ConsoleIO.promptForMenuSelection(gameMenu, true);
            switch (gameChosen) {
                case 0:
                    ConsoleIO.soutMethod("Goodbye then. Thank you for playing");
                    break;
                case 1:
                    //Code that connects Blackjack to this menu goes here
                    break;
                case 2:
                    //Code that connects Uno to this menu goes here
                    break;
                case 3:
                    //Code that connects Minesweeper to this menu goes here
                    minesweeper.runMinesweeper();
                    break;
            }
        }while (gameChosen != 0);
    }


}
